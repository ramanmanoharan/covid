<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <section class="page-header">
            <div class="container">
                <h2>All Records</h2>
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="#">Home</a></li>
                    <li><span>All Records</span></li>
                </ul><!-- /.thm-breadcrumb -->
            </div><!-- /.container -->
        </section><!-- /.page-header -->

	<!-- <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li><?php echo e($e['name']); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
	 <div class="card-body card">
                    <?php if(session('status')): ?>
                    
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                </div>

	<div class="container">
		<br><br>
		<table class="table table-bordered table-striped table-dark table-hover">
			<tr>
				<th>S.No</th>
				<th>NAME</th>
				<th>TITLE</th>
				<th>DESCRIPTION</th>
				<th>IMAGE</th>
				<th>EDIT</th>
				<th>DELETE</th>
			</tr>
			<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($e['id']); ?></td>
				<td><?php echo e($e['name']); ?></td>
				<td><?php echo e($e['title']); ?></td>
				<td><?php echo e($e['description']); ?></td>
				<td><img class="img-thumbnail" src="uploads/<?php echo e($e['image_name']); ?>"></td>
				<td><a href="edit/<?php echo e($e['id']); ?>">Edit</a></td>
				<td><a href="delete/<?php echo e($e['id']); ?>">Delete</a></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
	$(document).ready(function(){
		
    	$(".card").slideUp(10000);

	});
</script><?php /**PATH C:\xampp\htdocs\web\resources\views/totalrecord.blade.php ENDPATH**/ ?>